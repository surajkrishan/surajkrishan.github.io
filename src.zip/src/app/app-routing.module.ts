import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AddissueComponent } from './addissue/addissue.component';
import { ViewissueComponent } from './viewissue/viewissue.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'addissue', component: AddissueComponent},
  { path: 'viewissue', component: ViewissueComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
