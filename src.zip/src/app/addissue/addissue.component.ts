import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addissue',
  templateUrl: './addissue.component.html',
  styleUrls: ['./addissue.component.css']
})
export class AddissueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
