import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewissue',
  templateUrl: './viewissue.component.html',
  styleUrls: ['./viewissue.component.css']
})
export class ViewissueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
